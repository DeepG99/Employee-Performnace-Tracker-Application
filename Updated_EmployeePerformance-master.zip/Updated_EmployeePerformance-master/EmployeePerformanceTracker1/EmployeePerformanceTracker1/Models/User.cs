﻿namespace EmployeePerformanceTracker1.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string token { get; set; }
    }
}
